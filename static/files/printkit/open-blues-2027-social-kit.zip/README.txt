Open Blues 2027 — social images

facebook-post/  Facebook group post, Instagram feed (1080x1350)
instagram-square/  Instagram feed (1080x1080)
whatsapp/  WhatsApp, Signal, Messenger (1080x1080)
story/  Instagram & Facebook stories, WhatsApp status (1080x1920)
listing/  Event listings and link previews (1200x630)
facebook-event-cover/  Facebook event cover (1920x1005)

openblues.pl
